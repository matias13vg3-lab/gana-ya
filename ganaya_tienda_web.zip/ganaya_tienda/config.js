// Configuración de tu tienda GanaYa. Sustituye cada cadena vacía por el enlace HTTPS
// de compra que te proporcione Payhip, Gumroad u otro proveedor con descargas automáticas.
// ¡No publiques los archivos de productos dentro de esta carpeta!
window.STORE_CONFIG = {
  contactEmail: "",
  paymentLinks: {
    gastos: "",
    habitos: "",
    proyectos: "",
    pack: ""
  }
};
